package com.muriba.aihuman

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView

class FloatingAvatarService : Service() {
    private var windowManager: WindowManager? = null
    private var avatarView: TextView? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (avatarView != null) return START_STICKY
        val avatar = intent?.getStringExtra("avatar") ?: "Masculino"
        avatarView = TextView(this).apply {
            text = if (avatar == "Feminino") "👩\nMURIBA" else "👨\nMURIBA"
            textSize = 16f
            gravity = Gravity.CENTER
            setTextColor(0xFF00E676.toInt())
            setBackgroundColor(0xEE101820.toInt())
            setPadding(18, 18, 18, 18)
            setOnClickListener { text = if (text.toString().contains("MURIBA")) "Olá!\nMURIBA" else "MURIBA" }
        }
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = 24; y = 180 }
        windowManager?.addView(avatarView, params)
        return START_STICKY
    }

    override fun onDestroy() {
        avatarView?.let { windowManager?.removeView(it) }
        avatarView = null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
