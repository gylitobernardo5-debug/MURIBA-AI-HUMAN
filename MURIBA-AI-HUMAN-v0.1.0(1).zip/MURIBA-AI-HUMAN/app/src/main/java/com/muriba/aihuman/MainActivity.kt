package com.muriba.aihuman

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.util.Locale

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var selectedAvatar = "Masculino"
    private var selectedProvider = "Gemini"

    private val audioPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        Toast.makeText(this, if (granted) "Microfone autorizado" else "Permissão do microfone recusada", Toast.LENGTH_SHORT).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 36, 32, 24)
            setBackgroundColor(0xFF080B10.toInt())
        }
        fun label(text: String, size: Float = 18f) = TextView(this).apply {
            this.text = text; textSize = size; setTextColor(0xFFEAF2F8.toInt())
            setPadding(0, 14, 0, 14)
        }
        layout.addView(label("MURIBA AI HUMAN", 26f))
        layout.addView(label("O teu assistente virtual", 15f))

        layout.addView(label("Escolhe o avatar"))
        val avatar = Spinner(this)
        avatar.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("Masculino", "Feminino"))
        avatar.onItemSelectedListener = simpleListener { selectedAvatar = it }
        layout.addView(avatar)

        layout.addView(label("Motor de IA"))
        val provider = Spinner(this)
        provider.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("Gemini", "Grok"))
        provider.onItemSelectedListener = simpleListener { selectedProvider = it }
        layout.addView(provider)

        val status = label("Estado: pronto para configurar")
        layout.addView(status)

        val overlay = Button(this).apply {
            text = "ATIVAR AVATAR FLUTUANTE"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                } else {
                    startService(Intent(this@MainActivity, FloatingAvatarService::class.java)
                        .putExtra("avatar", selectedAvatar))
                    status.text = "Estado: avatar flutuante ativo"
                }
            }
        }
        layout.addView(overlay)

        layout.addView(Button(this).apply {
            text = "TESTAR VOZ"
            setOnClickListener {
                val msg = "Olá. Eu sou o Muriba AI Human. A minha voz está pronta."
                tts?.speak(msg, TextToSpeech.QUEUE_FLUSH, null, "muriba-intro")
            }
        })
        layout.addView(Button(this).apply {
            text = "AUTORIZAR MICROFONE"
            setOnClickListener {
                if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
                    audioPermission.launch(Manifest.permission.RECORD_AUDIO)
                else Toast.makeText(this@MainActivity, "Microfone já autorizado", Toast.LENGTH_SHORT).show()
            }
        })
        layout.addView(label("Nota: Gemini/Grok ainda precisam de ligação segura a um serviço de IA. Esta versão não envia áudio nem executa tarefas externas.", 13f))
        setContentView(ScrollView(this).apply { addView(layout) })
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) tts?.language = Locale("pt", "PT")
    }

    override fun onDestroy() {
        tts?.stop(); tts?.shutdown(); super.onDestroy()
    }

    private fun simpleListener(onSelect: (String) -> Unit) = object : android.widget.AdapterView.OnItemSelectedListener {
        override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
        override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
            onSelect(parent?.getItemAtPosition(position)?.toString() ?: "")
        }
    }
}
