# MURIBA AI HUMAN — Android starter v0.1.0

Projeto Android Kotlin preparado para compilar um APK de desenvolvimento.

## O que esta versão já contém
- Aplicação Android com tema escuro e acentos verde/azul.
- Seleção de avatar masculino/feminino.
- Seletor de fornecedor Gemini/Grok (seleção visual; ainda sem integração).
- Pedido de permissão para sobreposição e avatar flutuante simples.
- Teste de voz com TextToSpeech nativo.
- Pedido de permissão de microfone.
- GitHub Actions para compilar `app-debug.apk`.

## O que ainda NÃO está implementado
- Chamadas reais à API Gemini ou Grok.
- Reconhecimento de fala/conversa de áudio com a IA.
- Sincronização labial/visemas.
- Execução de tarefas em outras aplicações.
- Avatar 3D animado.

Estas funções exigem integração adicional, credenciais guardadas num backend seguro e testes num dispositivo real. Não coloques chaves de API dentro do APK ou num repositório público.

## Compilar
Requer JDK 17 e Gradle 8.9:
```bash
gradle assembleDebug
```
O APK de debug ficará em:
`app/build/outputs/apk/debug/app-debug.apk`

Também podes enviar o projeto para GitHub e executar o workflow **Build Android APK** em Actions.
